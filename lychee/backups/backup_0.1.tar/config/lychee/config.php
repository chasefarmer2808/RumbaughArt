<?php

// Database configuration
$dbHost = 'mysql'; // Host of the database
$dbUser = 'root'; // Username of the database
$dbPassword = 'suesteve'; // Password of the database
$dbName = 'lychee'; // Database name
$dbTablePrefix = ''; // Table prefix
